GURUMIN PSP OUTFITS

For Steam Gurumin 1.4. This folder contains only the outfits mod.

INSTALL
1. Close Gurumin.
2. Back up bin/map.itm in your game folder.
3. Copy THIS FOLDER'S CONTENTS into the Gurumin game folder. Allow bin/map.itm
   to be replaced. Do not place this outer folder inside the game folder.
4. Launch normally through Steam. No installer executable is required.

Windows: copying the files is sufficient.
Linux/Proton: Steam Properties > Launch Options:
  WINEDLLOVERRIDES="dinput8=n,b" %command%
With Gurumin Enhanced Rendering installed too:
  WINEDLLOVERRIDES="d3d9=n,b;dinput8=n,b" %command%
Preserve any other launch wrappers/options you already use.

PSP REQUIREMENTS
Buy Monkey Hat, Nightcap and Hair Buns from Hyperbolic on:
  Beginner -> Armor
  Normal   -> Princess
  Hard     -> Vampire
  Crazy    -> Samurai
  Happy    -> Witch
Santa is available December 25-31. Use the dresser in Parin's room.
Already earned difficulty-specific headgear awards are recognized there.
Existing PC costumes are preserved. This is not the renderer mod.

UNINSTALL
Change to Normal Clothes and save BEFORE removing the extra models.
Restore your backed-up bin/map.itm and remove only the files added by this mod.
Remove the dinput8 override on Linux, preserving other overrides.

The files were generated locally from your supplied PSP archive and owned PC
script. Keep this personal asset folder separate from the renderer repository.
Native hooking uses MinHook; see MinHook-LICENSE.txt.
